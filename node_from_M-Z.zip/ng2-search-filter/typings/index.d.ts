/// <reference path="globals/angular-protractor/index.d.ts" />
/// <reference path="globals/es6-shim/index.d.ts" />
/// <reference path="globals/jasmine/index.d.ts" />
/// <reference path="globals/selenium-webdriver/index.d.ts" />
