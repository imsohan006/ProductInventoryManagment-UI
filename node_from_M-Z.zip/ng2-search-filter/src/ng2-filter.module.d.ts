export declare class Ng2SearchPipeModule {
}
