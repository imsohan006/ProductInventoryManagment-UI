'use strict';

const BN = require('bn.js');

const p = new BN('2e1b162f326430f5ac6af10f96b2a8350e01675d22324c9f', 'hex');

console.log(p.bitLength());
