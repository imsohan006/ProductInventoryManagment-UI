import { ModuleWithProviders } from '@angular/core';
import { GlobalConfig } from './toastr-config';
export declare const DefaultGlobalConfig: GlobalConfig;
export declare class ToastrModule {
    static forRoot(config?: Partial<GlobalConfig>): ModuleWithProviders;
}
export declare class ToastrComponentlessModule {
    static forRoot(config?: Partial<GlobalConfig>): ModuleWithProviders;
}
