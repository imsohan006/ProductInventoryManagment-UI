export class Product{
    id: number;
    name: String;
    country: String;
}